/**
 * 打印功能测试
 * 测试ESC/POS打印指令生成、打印机状态等功能
 */

const axios = require('axios');
const chalk = require('chalk');

class PrintTests {
  constructor() {
    this.api = axios.create({
      baseURL: 'http://localhost:5000',
      timeout: 10000
    });
    this.testResults = {
      total: 0,
      passed: 0,
      failed: 0,
      errors: []
    };
  }

  async runAllTests() {
    console.log(chalk.blue('  开始打印功能测试...'));

    await this.testGenerateESCPos();
    await this.testPrintPreview();
    await this.testPrinterStatus();
    await this.testPrintSend();
    await this.testPrintValidation();

    return this.testResults;
  }

  async runTest(testName, testFunction) {
    this.testResults.total++;
    
    try {
      await testFunction();
      this.testResults.passed++;
      console.log(chalk.green(`    ✅ ${testName}`));
    } catch (error) {
      this.testResults.failed++;
      this.testResults.errors.push(`${testName}: ${error.message}`);
      console.log(chalk.red(`    ❌ ${testName}: ${error.message}`));
    }
  }

  // 测试ESC/POS指令生成
  async testGenerateESCPos() {
    await this.runTest('ESC/POS指令生成', async () => {
      const testSlip = `#投注单
TIME=2025-11-11 09:00:00
PLAY=竞彩篮球
PASS=3x1
1001>SF=主胜
2002>SFC=主胜6-10
3003>DXF=大
MULTI=10倍
TOTAL=60元
ENCODE=1001|3:2002|12:3003|1
@
`;

      const response = await this.api.post('/api/print/generate', {
        textSlip: testSlip,
        encodeSlip: '1001|3:2002|12:3003|1',
        paperWidth: 58,
        fontSize: 'normal',
        align: 'left'
      });

      if (!response.data.success) {
        throw new Error('生成ESC/POS指令失败');
      }

      const { escposBase64, escposHex, length } = response.data;
      
      if (!escposBase64) throw new Error('未返回Base64编码');
      if (!escposHex) throw new Error('未返回Hex编码');
      if (!length || length === 0) throw new Error('指令长度为0');
      
      // 验证Base64格式
      if (!/^[A-Za-z0-9+/]*={0,2}$/.test(escposBase64)) {
        throw new Error('Base64格式错误');
      }
      
      // 验证Hex格式
      if (!/^[0-9A-Fa-f]+$/.test(escposHex)) {
        throw new Error('Hex格式错误');
      }
    });
  }

  // 测试打印预览
  async testPrintPreview() {
    await this.runTest('打印预览', async () => {
      const testSlip = `#投注单
TIME=2025-11-11 09:00:00
PLAY=竞彩篮球
PASS=3x1
1001>SF=主胜
2002>SFC=主胜6-10
3003>DXF=大
MULTI=10倍
TOTAL=60元
ENCODE=1001|3:2002|12:3003|1
@
`;

      const response = await this.api.post('/api/print/preview', {
        textSlip: testSlip,
        encodeSlip: '1001|3:2002|12:3003|1',
        paperWidth: 58,
        fontSize: 'normal'
      });

      if (!response.data.success) {
        throw new Error('生成预览失败');
      }

      const { preview, dimensions } = response.data;
      
      if (!preview) throw new Error('未返回预览内容');
      if (!dimensions) throw new Error('未返回尺寸信息');
      if (dimensions.width !== 58) throw new Error('宽度设置错误');
      
      // 验证预览内容格式
      if (!preview.includes('彩票投注单')) throw new Error('预览标题缺失');
      if (!preview.includes('┌')) throw new Error('预览边框缺失');
    });
  }

  // 测试打印机状态
  async testPrinterStatus() {
    await this.runTest('打印机状态', async () => {
      // 获取打印机列表
      const listResponse = await this.api.get('/api/print/printers');
      
      if (!listResponse.data.success) {
        throw new Error('获取打印机列表失败');
      }

      const { printers } = listResponse.data;
      
      if (!Array.isArray(printers) || printers.length === 0) {
        throw new Error('打印机列表为空');
      }

      const defaultPrinter = printers.find(p => p.isDefault);
      if (!defaultPrinter) throw new Error('未找到默认打印机');

      // 获取打印机状态
      const statusResponse = await this.api.get(`/api/print/status/${defaultPrinter.id}`);
      
      if (!statusResponse.data.success) {
        throw new Error('获取打印机状态失败');
      }

      const { status } = statusResponse.data;
      
      if (typeof status.online !== 'boolean') throw new Error('在线状态错误');
      if (typeof status.ready !== 'boolean') throw new Error('就绪状态错误');
    });
  }

  // 测试打印发送
  async testPrintSend() {
    await this.runTest('打印发送', async () => {
      // 生成测试ESC/POS数据
      const testData = 'JEVTQFBPUyBUZXN0IERhdGE='; // "ESC/POS Test Data" in Base64
      
      const response = await this.api.post('/api/print/send', {
        printerId: 'PRN001',
        escposBase64: testData,
        copies: 1,
        paperWidth: 58,
        cutPaper: true
      });

      // 在开发环境中，打印可能是模拟的
      if (response.data.success) {
        // 验证返回结果
        const { jobId, printerStatus } = response.data;
        
        if (!jobId) throw new Error('未返回任务ID');
        if (!printerStatus) throw new Error('未返回打印机状态');
      } else {
        // 如果失败，检查是否是预期的错误（如打印机离线）
        if (response.data.printerStatus && response.data.printerStatus.online === false) {
          console.log(chalk.yellow('    ⚠️  打印机离线，跳过实际打印'));
        } else {
          throw new Error('打印发送失败: ' + response.data.message);
        }
      }
    });
  }

  // 测试打印验证
  async testPrintValidation() {
    await this.runTest('打印验证', async () => {
      // 测试无效参数
      try {
        await this.api.post('/api/print/send', {
          printerId: 'PRN001',
          // 缺少必要的 escposBase64
        });
        throw new Error('应该拒绝无效参数');
      } catch (error) {
        if (error.response && error.response.status === 400) {
          // 预期的错误
        } else {
          throw error;
        }
      }

      // 测试无效打印机ID
      try {
        await this.api.post('/api/print/send', {
          printerId: 'INVALID_PRINTER',
          escposBase64: 'dGVzdA==',
          copies: 1
        });
        throw new Error('应该拒绝无效打印机ID');
      } catch (error) {
        if (error.response && error.response.status === 500) {
          // 预期的错误
        } else {
          throw error;
        }
      }

      // 测试无效份数
      try {
        await this.api.post('/api/print/send', {
          printerId: 'PRN001',
          escposBase64: 'dGVzdA==',
          copies: -1
        });
        throw new Error('应该拒绝无效份数');
      } catch (error) {
        if (error.response && error.response.status === 400) {
          // 预期的错误
        } else {
          throw error;
        }
      }
    });
  }

  // 测试打印机测试功能
  async testPrinterTest() {
    await this.runTest('打印机测试', async () => {
      const response = await this.api.post('/api/print/test', {
        printerId: 'PRN001',
        paperWidth: 58
      });

      if (response.data.success) {
        const { jobId, printerStatus } = response.data;
        
        if (!jobId) throw new Error('未返回测试任务ID');
        if (!printerStatus) throw new Error('未返回打印机状态');
      } else {
        // 如果失败，检查是否是预期的错误
        if (response.data.printerStatus && response.data.printerStatus.online === false) {
          console.log(chalk.yellow('    ⚠️  打印机离线，跳过测试打印'));
        } else {
          throw new Error('打印机测试失败: ' + response.data.message);
        }
      }
    });
  }

  // 测试不同纸张宽度
  async testPaperWidths() {
    await this.runTest('纸张宽度测试', async () => {
      const testSlip = `#投注单\n测试内容\n@\n`;
      
      // 测试58mm
      const response58 = await this.api.post('/api/print/generate', {
        textSlip: testSlip,
        paperWidth: 58
      });
      
      if (!response58.data.success) {
        throw new Error('58mm纸张生成失败');
      }

      // 测试80mm
      const response80 = await this.api.post('/api/print/generate', {
        textSlip: testSlip,
        paperWidth: 80
      });
      
      if (!response80.data.success) {
        throw new Error('80mm纸张生成失败');
      }

      // 验证不同宽度的指令长度应该不同
      if (response58.data.length === response80.data.length) {
        throw new Error('不同纸张宽度的指令长度应该不同');
      }
    });
  }

  // 测试字体设置
  async testFontSettings() {
    await this.runTest('字体设置测试', async () => {
      const testSlip = `#投注单\n测试内容\n@\n`;
      
      // 测试正常字体
      const normalResponse = await this.api.post('/api/print/generate', {
        textSlip: testSlip,
        fontSize: 'normal'
      });
      
      if (!normalResponse.data.success) {
        throw new Error('正常字体生成失败');
      }

      // 测试大字体
      const largeResponse = await this.api.post('/api/print/generate', {
        textSlip: testSlip,
        fontSize: 'large'
      });
      
      if (!largeResponse.data.success) {
        throw new Error('大字体生成失败');
      }

      // 测试双倍字体
      const doubleResponse = await this.api.post('/api/print/generate', {
        textSlip: testSlip,
        fontSize: 'double'
      });
      
      if (!doubleResponse.data.success) {
        throw new Error('双倍字体生成失败');
      }
    });
  }
}

module.exports = PrintTests;