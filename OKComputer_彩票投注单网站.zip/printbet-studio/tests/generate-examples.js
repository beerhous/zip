/**
 * 示例投注单生成器
 * 生成足球比分、篮球比分、大乐透复式三个核心示例
 */

const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');

class ExampleGenerator {
  constructor() {
    this.api = axios.create({
      baseURL: 'http://localhost:5000',
      timeout: 10000
    });
    this.examplesDir = path.join(__dirname, '../examples');
    this.testResults = {
      total: 0,
      passed: 0,
      failed: 0,
      errors: []
    };
  }

  async generateAllExamples() {
    console.log(chalk.blue('  开始生成示例投注单...'));

    // 确保示例目录存在
    await fs.ensureDir(this.examplesDir);

    // 生成三个核心示例
    await this.generateFootballExample();
    await this.generateBasketballExample();
    await this.generateDLTExample();

    // 生成额外的示例
    await this.generateAdditionalExamples();

    return this.testResults;
  }

  async generateExample(testName, generateFunction) {
    this.testResults.total++;
    
    try {
      await generateFunction();
      this.testResults.passed++;
      console.log(chalk.green(`    ✅ ${testName}`));
    } catch (error) {
      this.testResults.failed++;
      this.testResults.errors.push(`${testName}: ${error.message}`);
      console.log(chalk.red(`    ❌ ${testName}: ${error.message}`));
    }
  }

  // 生成竞彩足球比分示例
  async generateFootballExample() {
    await this.generateExample('足球比分示例', async () => {
      const betData = {
        playType: 'football',
        passType: '2x1',
        multiplier: 5,
        bets: [
          { match: '周四004', type: 'BIFEN', choice: '2:1' },
          { match: '周五005', type: 'BIFEN', choice: '1:0' }
        ]
      };

      const response = await this.api.post('/api/bet/create', betData);
      
      if (!response.data.success) {
        throw new Error('创建投注单失败');
      }

      const { bet, textSlip, encodeSlip } = response.data;
      
      // 生成ESC/POS数据
      const printResponse = await this.api.post('/api/print/generate', {
        textSlip,
        encodeSlip,
        paperWidth: 58
      });

      const example = {
        name: '竞彩足球比分示例',
        description: '包含两个比分投注的竞彩足球投注单',
        betData: bet,
        textSlip,
        encodeSlip,
        escposBase64: printResponse.data.escposBase64,
        escposHex: printResponse.data.escposHex,
        preview: printResponse.data.preview
      };

      // 保存示例
      await fs.writeJson(
        path.join(this.examplesDir, 'football-bifen-example.json'),
        example,
        { spaces: 2 }
      );

      // 输出示例内容
      console.log(chalk.cyan('\n    📄 足球比分示例:'));
      console.log(chalk.gray('    ' + '-'.repeat(50)));
      console.log(textSlip);
      console.log(chalk.gray('    ' + '-'.repeat(50)));
      console.log(chalk.yellow(`    ENCODE: ${encodeSlip}`));
      console.log(chalk.yellow(`    ESC/POS长度: ${printResponse.data.length} 字节`));
    });
  }

  // 生成竞彩篮球比分示例
  async generateBasketballExample() {
    await this.generateExample('篮球比分示例', async () => {
      const betData = {
        playType: 'basketball',
        passType: '3x1',
        multiplier: 10,
        bets: [
          { match: '周一001', type: 'SF', choice: '主胜' },
          { match: '周二002', type: 'BIFEN', choice: '98:95' },
          { match: '周三003', type: 'SFC', choice: '主胜6-10' }
        ]
      };

      const response = await this.api.post('/api/bet/create', betData);
      
      if (!response.data.success) {
        throw new Error('创建投注单失败');
      }

      const { bet, textSlip, encodeSlip } = response.data;
      
      // 生成ESC/POS数据
      const printResponse = await this.api.post('/api/print/generate', {
        textSlip,
        encodeSlip,
        paperWidth: 58
      });

      const example = {
        name: '竞彩篮球比分示例',
        description: '包含胜负、比分、胜分差混合投注的竞彩篮球投注单',
        betData: bet,
        textSlip,
        encodeSlip,
        escposBase64: printResponse.data.escposBase64,
        escposHex: printResponse.data.escposHex,
        preview: printResponse.data.preview
      };

      // 保存示例
      await fs.writeJson(
        path.join(this.examplesDir, 'basketball-bifen-example.json'),
        example,
        { spaces: 2 }
      );

      // 输出示例内容
      console.log(chalk.cyan('\n    📄 篮球比分示例:'));
      console.log(chalk.gray('    ' + '-'.repeat(50)));
      console.log(textSlip);
      console.log(chalk.gray('    ' + '-'.repeat(50)));
      console.log(chalk.yellow(`    ENCODE: ${encodeSlip}`));
      console.log(chalk.yellow(`    ESC/POS长度: ${printResponse.data.length} 字节`));
    });
  }

  // 生成大乐透复式示例
  async generateDLTExample() {
    await this.generateExample('大乐透复式示例', async () => {
      const betData = {
        playType: 'dlt',
        multiplier: 2,
        bets: [{
          type: 'multiple',
          front: ['05', '12', '18', '23', '28', '31', '35'], // 7个前区号码
          back: ['03', '08', '11'], // 3个后区号码
          added: 1 // 追加
        }]
      };

      const response = await this.api.post('/api/bet/create', betData);
      
      if (!response.data.success) {
        throw new Error('创建投注单失败');
      }

      const { bet, textSlip, encodeSlip } = response.data;
      
      // 生成ESC/POS数据
      const printResponse = await this.api.post('/api/print/generate', {
        textSlip,
        encodeSlip,
        paperWidth: 58
      });

      const example = {
        name: '大乐透复式示例',
        description: '包含7个前区号码、3个后区号码并追加的大乐透复式投注单',
        betData: bet,
        textSlip,
        encodeSlip,
        escposBase64: printResponse.data.escposBase64,
        escposHex: printResponse.data.escposHex,
        preview: printResponse.data.preview
      };

      // 保存示例
      await fs.writeJson(
        path.join(this.examplesDir, 'dlt-multiple-example.json'),
        example,
        { spaces: 2 }
      );

      // 输出示例内容
      console.log(chalk.cyan('\n    📄 大乐透复式示例:'));
      console.log(chalk.gray('    ' + '-'.repeat(50)));
      console.log(textSlip);
      console.log(chalk.gray('    ' + '-'.repeat(50)));
      console.log(chalk.yellow(`    ENCODE: ${encodeSlip}`));
      console.log(chalk.yellow(`    ESC/POS长度: ${printResponse.data.length} 字节`));
    });
  }

  // 生成额外示例
  async generateAdditionalExamples() {
    console.log(chalk.blue('\n  生成额外示例...'));

    // 排列三单式
    await this.generatePLSSingleExample();
    
    // 排列五复式
    await this.generatePL5MultipleExample();
    
    // 竞彩足球混合过关
    await this.generateFootballMixedExample();
    
    // 竞彩篮球胜分差
    await this.generateBasketballSFCExample();
    
    // 大乐透胆拖
    await this.generateDLTDantuoExample();
  }

  // 排列三单式示例
  async generatePLSSingleExample() {
    await this.generateExample('排列三单式示例', async () => {
      const betData = {
        playType: 'pls',
        multiplier: 1,
        bets: [{
          type: 'single',
          numbers: ['1', '2', '3']
        }]
      };

      const response = await this.api.post('/api/bet/create', betData);
      const { textSlip, encodeSlip } = response.data;
      
      const printResponse = await this.api.post('/api/print/generate', {
        textSlip,
        encodeSlip,
        paperWidth: 58
      });

      await fs.writeJson(
        path.join(this.examplesDir, 'pls-single-example.json'),
        { name: '排列三单式示例', textSlip, encodeSlip, escposBase64: printResponse.data.escposBase64 },
        { spaces: 2 }
      );
    });
  }

  // 排列五复式示例
  async generatePL5MultipleExample() {
    await this.generateExample('排列五复式示例', async () => {
      const betData = {
        playType: 'pls',
        multiplier: 1,
        bets: [{
          type: 'multiple',
          gameType: 'pls5',
          numbers: ['1,2', '3,4', '5,6', '7,8', '9,0'] // 复式投注
        }]
      };

      const response = await this.api.post('/api/bet/create', betData);
      const { textSlip, encodeSlip } = response.data;
      
      const printResponse = await this.api.post('/api/print/generate', {
        textSlip,
        encodeSlip,
        paperWidth: 58
      });

      await fs.writeJson(
        path.join(this.examplesDir, 'pl5-multiple-example.json'),
        { name: '排列五复式示例', textSlip, encodeSlip, escposBase64: printResponse.data.escposBase64 },
        { spaces: 2 }
      );
    });
  }

  // 竞彩足球混合过关示例
  async generateFootballMixedExample() {
    await this.generateExample('竞彩足球混合示例', async () => {
      const betData = {
        playType: 'football',
        passType: '2x1',
        multiplier: 3,
        bets: [
          { match: '周六006', type: 'SPF', choice: '主胜' },
          { match: '周日007', type: 'RQSPF', choice: '让球客胜' }
        ]
      };

      const response = await this.api.post('/api/bet/create', betData);
      const { textSlip, encodeSlip } = response.data;
      
      const printResponse = await this.api.post('/api/print/generate', {
        textSlip,
        encodeSlip,
        paperWidth: 58
      });

      await fs.writeJson(
        path.join(this.examplesDir, 'football-mixed-example.json'),
        { name: '竞彩足球混合过关示例', textSlip, encodeSlip, escposBase64: printResponse.data.escposBase64 },
        { spaces: 2 }
      );
    });
  }

  // 竞彩篮球胜分差示例
  async generateBasketballSFCExample() {
    await this.generateExample('竞彩篮球胜分差示例', async () => {
      const betData = {
        playType: 'basketball',
        passType: '4x1',
        multiplier: 5,
        bets: [
          { match: '周一001', type: 'SFC', choice: '主胜1-5' },
          { match: '周二002', type: 'SFC', choice: '客胜6-10' },
          { match: '周三003', type: 'SFC', choice: '主胜11-15' },
          { match: '周四004', type: 'SFC', choice: '客胜16-20' }
        ]
      };

      const response = await this.api.post('/api/bet/create', betData);
      const { textSlip, encodeSlip } = response.data;
      
      const printResponse = await this.api.post('/api/print/generate', {
        textSlip,
        encodeSlip,
        paperWidth: 58
      });

      await fs.writeJson(
        path.join(this.examplesDir, 'basketball-sfc-example.json'),
        { name: '竞彩篮球胜分差示例', textSlip, encodeSlip, escposBase64: printResponse.data.escposBase64 },
        { spaces: 2 }
      );
    });
  }

  // 大乐透胆拖示例
  async generateDLTDantuoExample() {
    await this.generateExample('大乐透胆拖示例', async () => {
      const betData = {
        playType: 'dlt',
        multiplier: 1,
        bets: [{
          type: 'dantuo',
          front: {
            dan: ['05', '12'], // 胆码
            tuo: ['18', '23', '28', '31', '35'] // 拖码
          },
          back: ['03', '08'],
          added: 0
        }]
      };

      const response = await this.api.post('/api/bet/create', betData);
      const { textSlip, encodeSlip } = response.data;
      
      const printResponse = await this.api.post('/api/print/generate', {
        textSlip,
        encodeSlip,
        paperWidth: 58
      });

      await fs.writeJson(
        path.join(this.examplesDir, 'dlt-dantuo-example.json'),
        { name: '大乐透胆拖示例', textSlip, encodeSlip, escposBase64: printResponse.data.escposBase64 },
        { spaces: 2 }
      );
    });
  }

  // 生成汇总报告
  async generateSummary() {
    const examples = await fs.readdir(this.examplesDir);
    const summary = {
      generatedAt: new Date().toISOString(),
      totalExamples: examples.length,
      examples: []
    };

    for (const file of examples) {
      if (file.endsWith('.json')) {
        const example = await fs.readJson(path.join(this.examplesDir, file));
        summary.examples.push({
          name: example.name,
          file: file,
          betType: example.betData?.playType || 'unknown',
          totalAmount: example.betData?.totalAmount || 0,
          encodeLength: example.encodeSlip?.length || 0
        });
      }
    }

    await fs.writeJson(
      path.join(this.examplesDir, 'summary.json'),
      summary,
      { spaces: 2 }
    );

    console.log(chalk.green(`\n  ✅ 示例生成完成！共生成 ${summary.totalExamples} 个示例`));
    console.log(chalk.cyan('  示例保存在:'), this.examplesDir);
  }
}

module.exports = ExampleGenerator;