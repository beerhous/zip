/**
 * OCR功能测试
 * 测试OCR识别、解析等功能
 */

const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');

class OCRTests {
  constructor() {
    this.api = axios.create({
      baseURL: 'http://localhost:5000',
      timeout: 30000 // OCR可能需要更长时间
    });
    this.testResults = {
      total: 0,
      passed: 0,
      failed: 0,
      errors: []
    };
  }

  async runAllTests() {
    console.log(chalk.blue('  开始OCR功能测试...'));

    await this.testOCRWithMockImage();
    await this.testOCRWithRealImage();
    await this.testOCRValidation();
    await this.testOCRParsing();

    return this.testResults;
  }

  async runTest(testName, testFunction) {
    this.testResults.total++;
    
    try {
      await testFunction();
      this.testResults.passed++;
      console.log(chalk.green(`    ✅ ${testName}`));
    } catch (error) {
      this.testResults.failed++;
      this.testResults.errors.push(`${testName}: ${error.message}`);
      console.log(chalk.red(`    ❌ ${testName}: ${error.message}`));
    }
  }

  // 测试OCR识别（模拟图片）
  async testOCRWithMockImage() {
    await this.runTest('OCR识别测试', async () => {
      // 创建一个简单的测试图片数据
      const testImageData = Buffer.from('test-image-data').toString('base64');
      
      // 由于我们没有真实的图片文件，这里模拟一个OCR请求
      const mockImagePath = path.join(__dirname, 'test-images', 'basketball-bet.png');
      
      // 确保测试图片目录存在
      await fs.ensureDir(path.dirname(mockImagePath));
      
      // 如果测试图片不存在，创建一个简单的测试文件
      if (!await fs.pathExists(mockImagePath)) {
        await fs.writeFile(mockImagePath, 'mock-image-content');
      }

      const FormData = require('form-data');
      const form = new FormData();
      form.append('image', await fs.createReadStream(mockImagePath));

      const response = await this.api.post('/api/ocr', form, {
        headers: form.getHeaders()
      });

      if (!response.data.success) {
        throw new Error('OCR识别失败');
      }

      const { rawText, parsed, confidence } = response.data;
      
      if (!rawText) throw new Error('未返回识别文本');
      if (!parsed) throw new Error('未返回解析结果');
      if (confidence < 0.5) throw new Error('置信度过低');
      
      // 验证解析结果
      if (!parsed.playType) throw new Error('未识别出彩种类型');
      if (!parsed.results || parsed.results.length === 0) throw new Error('未识别出投注内容');
    });
  }

  // 测试OCR识别（真实图片）
  async testOCRWithRealImage() {
    await this.runTest('真实图片OCR测试', async () => {
      // 这里可以添加真实图片的测试
      // 由于我们没有真实的投注单图片，这里跳过
      console.log(chalk.yellow('    ⚠️  跳过：无真实测试图片'));
    });
  }

  // 测试OCR验证
  async testOCRValidation() {
    await this.runTest('OCR验证测试', async () => {
      // 测试无效图片格式
      try {
        const FormData = require('form-data');
        const form = new FormData();
        form.append('image', Buffer.from('invalid-image-data'), {
          filename: 'test.txt',
          contentType: 'text/plain'
        });

        await this.api.post('/api/ocr', form, {
          headers: form.getHeaders()
        });
        
        throw new Error('应该拒绝无效图片格式');
      } catch (error) {
        if (error.response && error.response.status === 400) {
          // 预期的错误
        } else {
          throw error;
        }
      }

      // 测试大文件
      try {
        const largeBuffer = Buffer.alloc(15 * 1024 * 1024); // 15MB
        const FormData = require('form-data');
        const form = new FormData();
        form.append('image', largeBuffer, {
          filename: 'large.jpg',
          contentType: 'image/jpeg'
        });

        await this.api.post('/api/ocr', form, {
          headers: form.getHeaders()
        });
        
        throw new Error('应该拒绝大文件');
      } catch (error) {
        if (error.response && error.response.status === 413) {
          // 预期的错误
        } else {
          throw error;
        }
      }
    });
  }

  // 测试OCR解析
  async testOCRParsing() {
    await this.runTest('OCR解析测试', async () => {
      // 测试不同彩种的解析
      const testCases = [
        {
          text: '竞彩篮球\n周一001 湖人VS勇士\n胜负 主胜\n倍数:10倍\n过关方式:3x1',
          expected: {
            playType: 'basketball',
            multiplier: 10,
            passType: '3x1'
          }
        },
        {
          text: '竞彩足球\n周四004 曼城VS利物浦\n比分 2:1\n倍数:5倍\n过关方式:2x1',
          expected: {
            playType: 'football',
            multiplier: 5,
            passType: '2x1'
          }
        },
        {
          text: '大乐透\n前区:05,12,23,28,35\n后区:03,08\n追加:是\n倍数:2倍',
          expected: {
            playType: 'dlt',
            multiplier: 2
          }
        }
      ];

      for (const testCase of testCases) {
        const parsed = this.parseOCRText(testCase.text);
        
        if (parsed.playType !== testCase.expected.playType) {
          throw new Error(`彩种解析错误: ${parsed.playType} !== ${testCase.expected.playType}`);
        }
        
        if (parsed.multiplier !== testCase.expected.multiplier) {
          throw new Error(`倍数解析错误: ${parsed.multiplier} !== ${testCase.expected.multiplier}`);
        }
        
        if (testCase.expected.passType && parsed.passType !== testCase.expected.passType) {
          throw new Error(`过关方式解析错误: ${parsed.passType} !== ${testCase.expected.passType}`);
        }
      }
    });
  }

  // 解析OCR文本（模拟后端的解析逻辑）
  parseOCRText(text) {
    const lines = text.split('\n').map(line => line.trim()).filter(line => line);
    
    let playType = '';
    let multiplier = 1;
    let passType = '1x1';
    
    // 检测彩种类型
    if (text.includes('竞彩篮球')) {
      playType = 'basketball';
    } else if (text.includes('竞彩足球')) {
      playType = 'football';
    } else if (text.includes('大乐透')) {
      playType = 'dlt';
    } else if (text.includes('排列三') || text.includes('排列五')) {
      playType = 'pls';
    }
    
    // 解析倍数
    const multiplierMatch = text.match(/倍数[:：]\s*(\d+)倍?/);
    if (multiplierMatch) {
      multiplier = parseInt(multiplierMatch[1]);
    }
    
    // 解析过关方式
    const passMatch = text.match(/过关方式[:：]\s*(\d+x\d+)/);
    if (passMatch) {
      passType = passMatch[1];
    }
    
    return {
      playType,
      multiplier,
      passType,
      results: this.extractBets(text, playType)
    };
  }

  // 提取投注项
  extractBets(text, playType) {
    const results = [];
    const lines = text.split('\n').map(line => line.trim()).filter(line => line);
    
    if (playType === 'basketball' || playType === 'football') {
      // 提取场次信息
      const matchPattern = /周[一二三四五六日]\d{3}/g;
      const matches = text.match(matchPattern) || [];
      
      matches.forEach(match => {
        const matchIndex = text.indexOf(match);
        const matchText = text.substring(matchIndex, matchIndex + 100);
        
        let type = '';
        let choice = '';
        
        if (playType === 'basketball') {
          if (matchText.includes('胜负')) {
            type = 'SF';
            choice = matchText.includes('主胜') ? '主胜' : '主负';
          } else if (matchText.includes('胜分差')) {
            type = 'SFC';
            const sfcMatch = matchText.match(/主胜(\d+-\d+)/);
            choice = sfcMatch ? `主胜${sfcMatch[1]}` : '主胜1-5';
          } else if (matchText.includes('大小分')) {
            type = 'DXF';
            choice = matchText.includes('大') ? '大' : '小';
          } else if (matchText.includes('比分')) {
            type = 'BIFEN';
            const scoreMatch = matchText.match(/(\d+:\d+)/);
            choice = scoreMatch ? scoreMatch[1] : '1:0';
          }
        } else if (playType === 'football') {
          if (matchText.includes('胜平负')) {
            type = 'SPF';
            if (matchText.includes('主胜')) choice = '主胜';
            else if (matchText.includes('平')) choice = '平';
            else choice = '客胜';
          } else if (matchText.includes('比分')) {
            type = 'BIFEN';
            const scoreMatch = matchText.match(/(\d+:\d+)/);
            choice = scoreMatch ? scoreMatch[1] : '1:0';
          }
        }
        
        if (type && choice) {
          results.push({
            match,
            type,
            choice,
            confidence: 0.9
          });
        }
      });
    } else if (playType === 'dlt') {
      // 提取大乐透号码
      const frontMatch = text.match(/前区[:：]\s*([\d,\s]+)/);
      const backMatch = text.match(/后区[:：]\s*([\d,\s]+)/);
      const addedMatch = text.match(/追加[:：]\s*(是|否|Y|N)/i);
      
      if (frontMatch && backMatch) {
        const frontNumbers = frontMatch[1].split(/[,\s]+/).map(n => n.trim()).filter(n => n);
        const backNumbers = backMatch[1].split(/[,\s]+/).map(n => n.trim()).filter(n => n);
        const added = addedMatch ? (addedMatch[1] === '是' || addedMatch[1].toUpperCase() === 'Y' ? '1' : '0') : '0';
        
        results.push({
          type: 'dlt',
          front: frontNumbers,
          back: backNumbers,
          added,
          confidence: 0.95
        });
      }
    }
    
    return results;
  }
}

module.exports = OCRTests;