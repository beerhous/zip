#!/usr/bin/env node

/**
 * PrintBet Studio 测试运行器
 * 执行所有自动化测试用例
 */

const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');

// 测试模块
const BetTests = require('./bet-tests');
const OCRTests = require('./ocr-tests');
const PrintTests = require('./print-tests');
const ExampleGenerator = require('./generate-examples');

class TestRunner {
  constructor() {
    this.testResults = {
      total: 0,
      passed: 0,
      failed: 0,
      errors: []
    };
  }

  async run() {
    console.log(chalk.blue.bold('\n🎯 PrintBet Studio 自动化测试\n'));
    console.log(chalk.gray('='.repeat(50)));

    const startTime = Date.now();

    try {
      // 1. 运行投注单测试
      await this.runBetTests();
      
      // 2. 运行OCR测试
      await this.runOCRTests();
      
      // 3. 运行打印测试
      await this.runPrintTests();
      
      // 4. 生成示例
      await this.generateExamples();

      const endTime = Date.now();
      const duration = (endTime - startTime) / 1000;

      this.printSummary(duration);

    } catch (error) {
      console.error(chalk.red('测试运行失败:'), error.message);
      process.exit(1);
    }
  }

  async runBetTests() {
    console.log(chalk.yellow('\n📋 运行投注单测试...'));
    
    const betTests = new BetTests();
    const results = await betTests.runAllTests();
    
    this.updateResults(results);
    this.printTestResults('投注单测试', results);
  }

  async runOCRTests() {
    console.log(chalk.yellow('\n📷 运行OCR测试...'));
    
    const ocrTests = new OCRTests();
    const results = await ocrTests.runAllTests();
    
    this.updateResults(results);
    this.printTestResults('OCR测试', results);
  }

  async runPrintTests() {
    console.log(chalk.yellow('\n🖨️  运行打印测试...'));
    
    const printTests = new PrintTests();
    const results = await printTests.runAllTests();
    
    this.updateResults(results);
    this.printTestResults('打印测试', results);
  }

  async generateExamples() {
    console.log(chalk.yellow('\n✨ 生成示例投注单...'));
    
    const exampleGenerator = new ExampleGenerator();
    const results = await exampleGenerator.generateAllExamples();
    
    this.updateResults(results);
    this.printTestResults('示例生成', results);
  }

  updateResults(results) {
    this.testResults.total += results.total;
    this.testResults.passed += results.passed;
    this.testResults.failed += results.failed;
    
    if (results.errors && results.errors.length > 0) {
      this.testResults.errors.push(...results.errors);
    }
  }

  printTestResults(testName, results) {
    const status = results.failed === 0 ? 
      chalk.green('✅ 通过') : 
      chalk.red('❌ 失败');

    console.log(`  ${status} ${testName}: ${results.passed}/${results.total} 通过`);
    
    if (results.failed > 0 && results.errors) {
      results.errors.forEach(error => {
        console.log(chalk.red(`    - ${error}`));
      });
    }
  }

  printSummary(duration) {
    console.log(chalk.gray('\n' + '='.repeat(50)));
    console.log(chalk.blue.bold('\n📊 测试结果汇总'));
    console.log(`总测试数: ${this.testResults.total}`);
    console.log(chalk.green(`通过: ${this.testResults.passed}`));
    console.log(chalk.red(`失败: ${this.testResults.failed}`));
    console.log(`耗时: ${duration.toFixed(2)}秒`);

    if (this.testResults.failed === 0) {
      console.log(chalk.green.bold('\n🎉 所有测试通过！'));
    } else {
      console.log(chalk.red.bold('\n⚠️  部分测试失败'));
      
      if (this.testResults.errors.length > 0) {
        console.log(chalk.red('\n错误详情:'));
        this.testResults.errors.forEach((error, index) => {
          console.log(chalk.red(`  ${index + 1}. ${error}`));
        });
      }
    }

    console.log(chalk.gray('\n' + '='.repeat(50)));
  }
}

// 如果直接运行此文件
if (require.main === module) {
  const runner = new TestRunner();
  runner.run().catch(error => {
    console.error(chalk.red('测试运行失败:'), error);
    process.exit(1);
  });
}

module.exports = TestRunner;