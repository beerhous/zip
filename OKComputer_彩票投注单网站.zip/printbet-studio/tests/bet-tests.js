/**
 * 投注单功能测试
 * 测试各种彩种的投注单创建、验证、编码等功能
 */

const axios = require('axios');
const chalk = require('chalk');

class BetTests {
  constructor() {
    this.api = axios.create({
      baseURL: 'http://localhost:5000',
      timeout: 10000
    });
    this.testResults = {
      total: 0,
      passed: 0,
      failed: 0,
      errors: []
    };
  }

  async runAllTests() {
    console.log(chalk.blue('  开始投注单功能测试...'));

    await this.testBasketballBet();
    await this.testFootballBet();
    await this.testDLTBet();
    await this.testPLSBet();
    await this.testValidation();
    await this.testCalculation();
    await this.testMappings();

    return this.testResults;
  }

  async runTest(testName, testFunction) {
    this.testResults.total++;
    
    try {
      await testFunction();
      this.testResults.passed++;
      console.log(chalk.green(`    ✅ ${testName}`));
    } catch (error) {
      this.testResults.failed++;
      this.testResults.errors.push(`${testName}: ${error.message}`);
      console.log(chalk.red(`    ❌ ${testName}: ${error.message}`));
    }
  }

  // 测试竞彩篮球投注单
  async testBasketballBet() {
    await this.runTest('竞彩篮球投注单', async () => {
      const betData = {
        playType: 'basketball',
        passType: '3x1',
        multiplier: 10,
        bets: [
          { match: '周一001', type: 'SF', choice: '主胜' },
          { match: '周二002', type: 'SFC', choice: '主胜6-10' },
          { match: '周三003', type: 'DXF', choice: '大' }
        ]
      };

      const response = await this.api.post('/api/bet/create', betData);
      
      if (!response.data.success) {
        throw new Error('创建投注单失败');
      }

      const { bet } = response.data;
      
      // 验证结果
      if (bet.playType !== 'basketball') throw new Error('彩种类型错误');
      if (bet.passType !== '3x1') throw new Error('过关方式错误');
      if (bet.multiplier !== 10) throw new Error('倍数错误');
      if (bet.bets.length !== 3) throw new Error('投注项数量错误');
      if (bet.totalBets !== 3) throw new Error('总注数计算错误');
      if (bet.totalAmount !== 60) throw new Error('总金额计算错误');
      if (!bet.encode) throw new Error('编码生成失败');
      if (!bet.textSlip) throw new Error('文本生成失败');
    });
  }

  // 测试竞彩足球投注单
  async testFootballBet() {
    await this.runTest('竞彩足球投注单', async () => {
      const betData = {
        playType: 'football',
        passType: '2x1',
        multiplier: 5,
        bets: [
          { match: '周四004', type: 'BIFEN', choice: '2:1' },
          { match: '周五005', type: 'TG', choice: '3球' }
        ]
      };

      const response = await this.api.post('/api/bet/create', betData);
      
      if (!response.data.success) {
        throw new Error('创建投注单失败');
      }

      const { bet } = response.data;
      
      // 验证结果
      if (bet.playType !== 'football') throw new Error('彩种类型错误');
      if (bet.passType !== '2x1') throw new Error('过关方式错误');
      if (bet.multiplier !== 5) throw new Error('倍数错误');
      if (bet.bets.length !== 2) throw new Error('投注项数量错误');
      if (bet.totalAmount !== 20) throw new Error('总金额计算错误');
      if (!bet.encode.includes('21')) throw new Error('比分编码错误');
    });
  }

  // 测试大乐透投注单
  async testDLTBet() {
    await this.runTest('大乐透投注单', async () => {
      const betData = {
        playType: 'dlt',
        multiplier: 2,
        bets: [{
          type: 'multiple',
          front: ['05', '12', '23', '28', '35'],
          back: ['03', '08'],
          added: 1
        }]
      };

      const response = await this.api.post('/api/bet/create', betData);
      
      if (!response.data.success) {
        throw new Error('创建投注单失败');
      }

      const { bet } = response.data;
      
      // 验证结果
      if (bet.playType !== 'dlt') throw new Error('彩种类型错误');
      if (bet.multiplier !== 2) throw new Error('倍数错误');
      if (bet.totalAmount !== 6) throw new Error('总金额计算错误（含追加）');
      if (!bet.encode.includes('DLT')) throw new Error('大乐透编码错误');
      if (!bet.encode.includes('FR:')) throw new Error('前区编码错误');
      if (!bet.encode.includes('BK:')) throw new Error('后区编码错误');
    });
  }

  // 测试排列三投注单
  async testPLSBet() {
    await this.runTest('排列三投注单', async () => {
      const betData = {
        playType: 'pls',
        multiplier: 1,
        bets: [{
          type: 'single',
          numbers: ['1', '2', '3']
        }]
      };

      const response = await this.api.post('/api/bet/create', betData);
      
      if (!response.data.success) {
        throw new Error('创建投注单失败');
      }

      const { bet } = response.data;
      
      // 验证结果
      if (bet.playType !== 'pls') throw new Error('彩种类型错误');
      if (bet.totalAmount !== 2) throw new Error('总金额计算错误');
      if (!bet.encode.includes('PLS')) throw new Error('排列三编码错误');
      if (!bet.encode.includes('N:')) throw new Error('号码编码错误');
    });
  }

  // 测试投注单验证
  async testValidation() {
    await this.runTest('投注单验证', async () => {
      // 测试无效投注单
      const invalidBet = {
        playType: '',
        bets: []
      };

      const response = await this.api.post('/api/bet/validate', invalidBet);
      
      if (!response.data.valid) {
        throw new Error('应该验证失败但通过了');
      }

      // 测试有效投注单
      const validBet = {
        playType: 'basketball',
        bets: [{ match: '周一001', type: 'SF', choice: '主胜' }]
      };

      const validResponse = await this.api.post('/api/bet/validate', validBet);
      
      if (!validResponse.data.valid) {
        throw new Error('有效投注单验证失败');
      }
    });
  }

  // 测试计算功能
  async testCalculation() {
    await this.runTest('计算功能', async () => {
      const calcData = {
        playType: 'basketball',
        bets: [
          { match: '周一001', type: 'SF', choice: '主胜' },
          { match: '周二002', type: 'SF', choice: '主负' },
          { match: '周三003', type: 'SF', choice: '主胜' }
        ],
        multiplier: 5
      };

      const response = await this.api.post('/api/bet/calculate', calcData);
      
      if (!response.data.success) {
        throw new Error('计算失败');
      }

      const { totalBets, totalAmount } = response.data;
      
      if (totalBets !== 3) throw new Error('注数计算错误');
      if (totalAmount !== 30) throw new Error('金额计算错误');
    });
  }

  // 测试映射表
  async testMappings() {
    await this.runTest('映射表', async () => {
      // 测试篮球映射
      const basketballResponse = await this.api.get('/api/bet/mappings/basketball');
      
      if (!basketballResponse.data.success) {
        throw new Error('获取篮球映射失败');
      }

      const basketballMappings = basketballResponse.data.mappings;
      
      if (!basketballMappings.mappings.SF) throw new Error('篮球胜负映射不存在');
      if (!basketballMappings.mappings.SFC) throw new Error('篮球胜分差映射不存在');
      if (!basketballMappings.mappings.DXF) throw new Error('篮球大小分映射不存在');

      // 测试足球映射
      const footballResponse = await this.api.get('/api/bet/mappings/football');
      
      if (!footballResponse.data.success) {
        throw new Error('获取足球映射失败');
      }

      const footballMappings = footballResponse.data.mappings;
      
      if (!footballMappings.mappings.SPF) throw new Error('足球胜平负映射不存在');
      if (!footballMappings.mappings.BIFEN) throw new Error('足球比分映射不存在');
    });
  }
}

module.exports = BetTests;