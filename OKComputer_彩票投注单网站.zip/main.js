// PrintBet Studio - 主要JavaScript功能

// 全局变量
let currentBetData = {
    playType: 'basketball',
    passType: '1x1',
    multiplier: 1,
    bets: []
};

let ocrResult = null;

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    initializeAnimations();
});

// 初始化应用
function initializeApp() {
    console.log('PrintBet Studio 初始化...');
    
    // 初始化滚动进度条
    updateScrollProgress();
    
    // 初始化投注单
    initializeBetForm();
    
    // 初始化示例数据
    initializeExamples();
    
    console.log('PrintBet Studio 初始化完成');
}

// 设置事件监听器
function setupEventListeners() {
    // 文件上传相关
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('fileInput');
    
    dropzone.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileSelect);
    
    // 拖拽上传
    dropzone.addEventListener('dragover', handleDragOver);
    dropzone.addEventListener('dragleave', handleDragLeave);
    dropzone.addEventListener('drop', handleDrop);
    
    // 表单变化监听
    document.getElementById('playType').addEventListener('change', updatePlayType);
    document.getElementById('passType').addEventListener('change', updatePassType);
    document.getElementById('multiplier').addEventListener('input', updateMultiplier);
    document.getElementById('paperWidth').addEventListener('change', updatePrintPreview);
    
    // 滚动事件
    window.addEventListener('scroll', updateScrollProgress);
    
    // 平滑滚动
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// 初始化动画
function initializeAnimations() {
    // 滚动动画
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // 为需要动画的元素添加观察
    document.querySelectorAll('.feature-card, .workflow-step, .stats-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// 更新滚动进度
function updateScrollProgress() {
    const scrollTop = window.pageYOffset;
    const docHeight = document.body.scrollHeight - window.innerHeight;
    const scrollPercent = (scrollTop / docHeight) * 100;
    
    document.getElementById('scrollProgress').style.width = scrollPercent + '%';
}

// 滚动到演示区域
function scrollToDemo() {
    document.getElementById('demo').scrollIntoView({
        behavior: 'smooth'
    });
}

// 滚动到下载区域
function scrollToDownload() {
    document.getElementById('download').scrollIntoView({
        behavior: 'smooth'
    });
}

// 文件选择处理
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (file) {
        processImage(file);
    }
}

// 拖拽处理
function handleDragOver(event) {
    event.preventDefault();
    event.currentTarget.classList.add('dragover');
}

function handleDragLeave(event) {
    event.currentTarget.classList.remove('dragover');
}

function handleDrop(event) {
    event.preventDefault();
    event.currentTarget.classList.remove('dragover');
    
    const files = event.dataTransfer.files;
    if (files.length > 0) {
        processImage(files[0]);
    }
}

// 处理图片上传和OCR识别
async function processImage(file) {
    // 验证文件类型
    if (!file.type.startsWith('image/')) {
        showNotification('请选择图片文件', 'error');
        return;
    }
    
    // 验证文件大小（10MB限制）
    if (file.size > 10 * 1024 * 1024) {
        showNotification('图片文件不能超过10MB', 'error');
        return;
    }
    
    // 显示上传进度
    showUploadProgress();
    
    try {
        // 模拟OCR识别过程
        await simulateOCRProcess(file);
        
        // 显示识别结果
        showOCRResult();
        
    } catch (error) {
        showNotification('OCR识别失败，请重试', 'error');
        hideUploadProgress();
    }
}

// 模拟OCR处理过程
function simulateOCRProcess(file) {
    return new Promise((resolve) => {
        setTimeout(() => {
            // 模拟OCR识别结果
            ocrResult = {
                success: true,
                text: `竞彩篮球
周一001 湖人VS勇士
胜负 主胜
周二002 篮网VS凯尔特人  
胜分差 主胜6-10
周三003 火箭VS雷霆
大小分 大
倍数:10倍
过关方式:3x1`,
                confidence: 0.95,
                parsed: {
                    playType: 'basketball',
                    passType: '3x1',
                    multiplier: 10,
                    results: [
                        { match: '周一001', type: 'SF', choice: '主胜' },
                        { match: '周二002', type: 'SFC', choice: '主胜6-10' },
                        { match: '周三003', type: 'DXF', choice: '大' }
                    ]
                }
            };
            resolve();
        }, 2000);
    });
}

// 显示上传进度
function showUploadProgress() {
    document.getElementById('uploadContent').classList.add('hidden');
    document.getElementById('uploadProgress').classList.remove('hidden');
}

// 隐藏上传进度
function hideUploadProgress() {
    document.getElementById('uploadContent').classList.remove('hidden');
    document.getElementById('uploadProgress').classList.add('hidden');
}

// 显示OCR识别结果
function showOCRResult() {
    hideUploadProgress();
    
    const ocrResultDiv = document.getElementById('ocrResult');
    const ocrTextDiv = document.getElementById('ocrText');
    
    ocrTextDiv.textContent = ocrResult.text;
    ocrResultDiv.classList.remove('hidden');
    
    // 添加动画效果
    anime({
        targets: ocrResultDiv,
        opacity: [0, 1],
        translateY: [20, 0],
        duration: 500,
        easing: 'easeOutQuad'
    });
}

// 应用OCR识别结果
function applyOCRResult() {
    if (!ocrResult || !ocrResult.parsed) {
        showNotification('没有可应用的识别结果', 'warning');
        return;
    }
    
    const parsed = ocrResult.parsed;
    
    // 更新表单数据
    document.getElementById('playType').value = parsed.playType;
    document.getElementById('passType').value = parsed.passType;
    document.getElementById('multiplier').value = parsed.multiplier;
    
    // 更新全局数据
    currentBetData.playType = parsed.playType;
    currentBetData.passType = parsed.passType;
    currentBetData.multiplier = parsed.multiplier;
    currentBetData.bets = parsed.results.map(result => ({
        id: Date.now() + Math.random(),
        match: result.match,
        type: result.type,
        choice: result.choice
    }));
    
    // 更新投注单显示
    updateBetItemsList();
    calculateTotals();
    updatePrintPreview();
    
    showNotification('识别结果已应用', 'success');
    
    // 隐藏OCR结果
    document.getElementById('ocrResult').classList.add('hidden');
}

// 初始化投注单表单
function initializeBetForm() {
    updateBetItemsList();
    calculateTotals();
    updatePrintPreview();
}

// 更新彩种类型
function updatePlayType() {
    currentBetData.playType = document.getElementById('playType').value;
    updateBetItemsList();
    updatePrintPreview();
}

// 更新过关方式
function updatePassType() {
    currentBetData.passType = document.getElementById('passType').value;
    updatePrintPreview();
}

// 更新倍数
function updateMultiplier() {
    currentBetData.multiplier = parseInt(document.getElementById('multiplier').value) || 1;
    calculateTotals();
    updatePrintPreview();
}

// 添加投注项
function addBetItem() {
    const newBet = {
        id: Date.now() + Math.random(),
        match: '周一001',
        type: 'SF',
        choice: '主胜'
    };
    
    currentBetData.bets.push(newBet);
    updateBetItemsList();
    calculateTotals();
    updatePrintPreview();
}

// 删除投注项
function removeBetItem(id) {
    currentBetData.bets = currentBetData.bets.filter(bet => bet.id !== id);
    updateBetItemsList();
    calculateTotals();
    updatePrintPreview();
}

// 更新投注项列表显示
function updateBetItemsList() {
    const container = document.getElementById('betItemsList');
    container.innerHTML = '';
    
    if (currentBetData.bets.length === 0) {
        container.innerHTML = `
            <div class="text-center text-gray-500 py-4 border-2 border-dashed border-gray-300 rounded-lg">
                <i class="fas fa-plus-circle text-2xl mb-2"></i>
                <p>点击